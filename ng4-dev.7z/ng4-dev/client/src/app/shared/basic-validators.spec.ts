/* tslint:disable:no-unused-variable */

import { addProviders, async, inject } from '@angular/core/testing';
import {BasicValidators} from './basic-validators';

describe('BasicValidators', () => {
  it('should create an instance', () => {
    expect(new BasicValidators()).toBeTruthy();
  });
});
