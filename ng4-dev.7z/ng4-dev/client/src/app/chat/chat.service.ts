import { Injectable } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';
import * as io from 'socket.io-client';
import { Call } from './../common/call';

@Injectable()
export class ChatService {
  private call: Call = new Call();
  // private url = 'http://10.100.60.120:8080';  
  private socket;
  constructor() {

  }
  sendMessage(message) {
    this.socket.emit('add-message', message);
  }

  getMessages() {
    console.log(this.call.getUrl());
    
    let observable = new Observable(observer => {
      this.socket = io(this.call.getUrl());
      this.socket.on('message', (data) => {
        observer.next(data);
      });
      return () => {
        this.socket.disconnect();
      };
    })
    return observable;
  }
}