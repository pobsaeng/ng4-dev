export class Call {
    constructor() {}
    getUrl() {
        var url = "";
        var host = window.location.host;
        if (host === 'http://10.100.72.109') {
            url = 'http://10.100.72.109:5000';
        } else {
            // url = window.location.protocol+"//"+window.location.host + "/BAYWebServiceGateWay3/GateWay";
            url = window.location.protocol+"//"+window.location.host + "/BAYWebServiceGateWay3/GateWay";
        }
        return url;
    }
    getServiceUrl(){
        //window.location.protocol+"//"+window.location.host + "/BAYWebServiceGateWay3/GateWay";
        return 'http://10.100.72.109/pservice.php';
    }
}