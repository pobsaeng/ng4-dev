import { Component, OnInit } from '@angular/core';
import {DocumentService} from "./shared/document.service";
import {Doc} from "./shared/doc";

@Component({
  selector: 'app-idoc',
  templateUrl: './idoc.component.html',
  styleUrls: ['./idoc.component.css']
})
export class IdocComponent implements OnInit {

  private docs: Doc[] = [];

  constructor(private documentService: DocumentService) { }

  ngOnInit() {
    let params = this.getDocumentSet('161207142157941', 'BKK');

    this.documentService.getDocs(params)
      .subscribe(data => {
        console.log(data);
      });
  }

  getDocumentSet(docSetId, hubId): string {
    let values = '';
    var data = {
      'serviceMethod': 'com.biztech.idociapps.document.onescreen.service.CreditOneScreenService#getDocumentSet',
      'serviceParams': '[{"value":"' + docSetId + '"}, {"value":"' + hubId + '"}]'
    };
    values = 'request=' + this.objToString(data);
    return values;
  }
  objToString(obj): string {
    var str = '';
    for (var p in obj) {
      if (obj.hasOwnProperty(p)) {
        str += p + ':' + obj[p] + '\n';
      }
    }
    return str;
  }

}
