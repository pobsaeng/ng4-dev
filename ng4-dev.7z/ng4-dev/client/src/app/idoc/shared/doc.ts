export class Doc {
  objectId: string;
  creditDocumentSetId: string;
  seq: string;
  documentType: string;
  creditDocumentDetailVOs: Object;
}
