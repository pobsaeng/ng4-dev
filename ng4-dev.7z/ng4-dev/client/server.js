const express = require('express');
const http = require('http');
const path = require('path');
var fs = require('fs');
const app = express();
const server = http.createServer(app);
let io = require('socket.io')(server);

app.use(express.static(path.join(__dirname, '/client')));

app.get('/', function(req, res){
	let file = process.cwd() + 'index.html';                                                   
	res.writeHead(200, {"Content-Type": "text/html"});                                                
	fs.createReadStream(file).pipe(res);
});

io.on('connection', (socket) => {
  console.log('user connected');
  
  socket.on('disconnect', function(){
    console.log('user disconnected');
  });
  
  socket.on('add-message', (message) => {
	  console.log(message);	
    io.emit('message', {type:'new-message', text: message});    
  });
});

server.listen(5000, () => {
  console.log('started on port ' + server.address().port);
});
